# بناء APK لِـ لسان

**لم يتم إنشاء APK في هذه البيئة.** لا يتوفر Flutter SDK أو Android SDK هنا، كما أن تنزيل الأدوات والحزم غير ممكن بسبب عدم توفر اتصال الشبكة.

لإتمام البناء من خلال GitHub:
1. أنشئ مستودعًا جديدًا على GitHub وارفع محتويات هذا المشروع.
2. افتح **Actions**.
3. اختر **Build Lisaan APK** ثم **Run workflow**.
4. عند نجاح التشغيل، نزّل artifact باسم `lisaan-release-apk`.

سير العمل ينشئ مجلد Android باستخدام Flutter ثم ينفذ `flutter pub get` و`flutter build apk --release` ويرفع APK كـ artifact.
