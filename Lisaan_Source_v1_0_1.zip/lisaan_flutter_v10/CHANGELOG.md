# سجل التغييرات
## v0.8
- مزامنة تمييز الجملة مع الفيديو المحلي.
- خيار تكرار الجملة المحددة تلقائيًا للفيديو المحلي.
- نطق الجمل والترجمات بواسطة TTS على الجهاز.


## v0.9
- Added a quick action to save an individual word/expression from a subtitle sentence with its Arabic meaning.
- Added a vocabulary-only filter and flashcard review mode in the saved-items screen.
- Improved transcript timestamp parsing to tolerate numeric seconds and millisecond values from different APIs.
- Existing v0.8 features remain; external transcript/translation services still require configuration and were not verified against a live API in this build.


## v1.0.0
- Consolidated the core learning flow: YouTube/local video, timed subtitles, translation, sentence TTS, vocabulary saving, flashcard review, subtitle/backup export, and speech recognition.
- Added a retry-translation action for imported/extracted subtitle lines.
- Added a rough text-overlap indicator to pronunciation practice, with a clear disclaimer that it is not acoustic pronunciation scoring.
- Updated app package version to 1.0.0+10.
- Build, device behavior, and live external API schemas remain unverified in this environment.


## v1.0.1
- Fixed a compile error (invalid `Wrap(mainAxisSize: ...)` in the sentence list); sentence actions now sit under each sentence.
- Language dropdown in API settings now updates inside the dialog.
- Safer disposal order for video/YouTube controllers when switching videos.
- Local video play/pause icon and time now refresh during playback.
- Subtitle picker accepts any file and validates SRT/VTT/TXT by extension (Android MIME issue).
- Workflow: JDK 17, manifest `<queries>` for speech recognition and TTS (needed on Android 11+), robust permission insertion, app label.
