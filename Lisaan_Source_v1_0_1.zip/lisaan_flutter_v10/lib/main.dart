import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import 'package:file_picker/file_picker.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:video_player/video_player.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

void main() => runApp(const LisaanApp());

const brand = Color(0xFF176B5B);
const bg = Color(0xFFF4F7F5);

class LisaanApp extends StatelessWidget {
  const LisaanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'لسان',
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: brand),
      scaffoldBackgroundColor: bg,
      appBarTheme: const AppBarTheme(backgroundColor: bg, centerTitle: false),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const HomePage(),
  );
}

class Phrase {
  final String source;
  final String translation;
  final String context;
  final DateTime savedAt;
  Phrase(this.source, this.translation, this.context, this.savedAt);
  Map<String, dynamic> toJson() => {
    'source': source, 'translation': translation, 'context': context,
    'savedAt': savedAt.toIso8601String()
  };
  factory Phrase.fromJson(Map<String, dynamic> j) => Phrase(
    j['source'] ?? '', j['translation'] ?? '', j['context'] ?? '',
    DateTime.tryParse(j['savedAt'] ?? '') ?? DateTime.now(),
  );
}

class SubtitleLine {
  final Duration start;
  final Duration end;
  final String text;
  final String translation;
  const SubtitleLine(this.start, this.end, this.text, [this.translation = '']);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final List<Phrase> phrases = [];
  final List<Map<String, String>> recent = [];
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getStringList('phrases_v5') ?? [];
    final urls = p.getStringList('recent_v5') ?? [];
    if (!mounted) return;
    setState(() {
      phrases.addAll(raw.map((s) => Phrase.fromJson(jsonDecode(s))));
      recent.addAll(urls.map((s) => Map<String,String>.from(jsonDecode(s))));
    });
  }
  Future<void> savePhrase(Phrase phrase) async {
    if (phrases.any((p) => p.source == phrase.source && p.translation == phrase.translation)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذه العبارة محفوظة بالفعل')));
      return;
    }
    setState(() => phrases.insert(0, phrase));
    final p = await SharedPreferences.getInstance();
    await p.setStringList('phrases_v5', phrases.map((x) => jsonEncode(x.toJson())).toList());
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ العبارة')));
  }
  Future<void> saveRecent(String url, String title) async {
    recent.removeWhere((x) => x['url'] == url);
    recent.insert(0, {'url': url, 'title': title});
    if (recent.length > 15) recent.removeRange(15, recent.length);
    final p = await SharedPreferences.getInstance();
    await p.setStringList('recent_v5', recent.map(jsonEncode).toList());
    if (mounted) setState(() {});
  }
  Future<void> deletePhrase(int index) async {
    setState(() => phrases.removeAt(index));
    final p = await SharedPreferences.getInstance();
    await p.setStringList('phrases_v5', phrases.map((x) => jsonEncode(x.toJson())).toList());
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      LearnPage(onSave: savePhrase, recent: recent, onRecent: saveRecent),
      SavedPage(phrases: phrases, onDelete: deletePhrase),
      const GuidePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          CircleAvatar(backgroundColor: brand, child: Icon(Icons.translate, color: Colors.white)),
          SizedBox(width: 10), Text('لسان', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [Padding(padding: const EdgeInsetsDirectional.only(end: 16), child: Center(child: Text('v1.0.1', style: TextStyle(color: Colors.grey.shade700))))],
      ),
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'تعلّم'),
          NavigationDestination(icon: Icon(Icons.bookmark_outline), selectedIcon: Icon(Icons.bookmark), label: 'عباراتي'),
          NavigationDestination(icon: Icon(Icons.help_outline), selectedIcon: Icon(Icons.help), label: 'الدليل'),
        ],
      ),
    );
  }
}

class LearnPage extends StatefulWidget {
  final Future<void> Function(Phrase) onSave;
  final List<Map<String,String>> recent;
  final Future<void> Function(String,String) onRecent;
  const LearnPage({super.key, required this.onSave, required this.recent, required this.onRecent});
  @override
  State<LearnPage> createState() => _LearnPageState();
}

class _LearnPageState extends State<LearnPage> {
  final urlCtrl = TextEditingController();
  final sourceCtrl = TextEditingController();
  final translationCtrl = TextEditingController();
  final searchCtrl = TextEditingController();
  YoutubePlayerController? yt;
  VideoPlayerController? local;
  bool localReady = false;
  bool listening = false;
  bool autoScroll = true;
  double speed = 1;
  String videoTitle = 'لم يتم اختيار فيديو';
  String status = 'أدخل رابط YouTube أو افتح فيديو من جهازك';
  List<SubtitleLine> lines = [];
  int current = -1;
  bool _lastPlaying = false;
  int _lastSecond = -1;
  final stt.SpeechToText speech = stt.SpeechToText();
  String recognized = '';
  String speechLocale = 'en_US';
  final transcriptKeyCtrl = TextEditingController();
  final translateUrlCtrl = TextEditingController(text: 'https://libretranslate.com');
  final translateKeyCtrl = TextEditingController();
  String targetLanguage = 'ar';
  bool autoBusy = false;
  bool allowPaidAsr = false;
  bool repeatSentence = false;
  bool followPlayback = true;
  bool isSpeaking = false;
  final FlutterTts tts = FlutterTts();
  String autoInfo = '';

  @override
  void initState() {
    super.initState();
    _loadApiSettings();
  }
  Future<void> _loadApiSettings() async {
    tts.setStartHandler(() { if (mounted) setState(() => isSpeaking = true); });
    tts.setCompletionHandler(() { if (mounted) setState(() => isSpeaking = false); });
    tts.setCancelHandler(() { if (mounted) setState(() => isSpeaking = false); });
    final p = await SharedPreferences.getInstance();
    transcriptKeyCtrl.text = p.getString('transcript_api_key') ?? '';
    translateUrlCtrl.text = p.getString('translate_base_url') ?? 'https://libretranslate.com';
    translateKeyCtrl.text = p.getString('translate_api_key') ?? '';
    targetLanguage = p.getString('target_language') ?? 'ar';
    allowPaidAsr = p.getBool('allow_paid_asr') ?? false;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    urlCtrl.dispose(); sourceCtrl.dispose(); translationCtrl.dispose(); searchCtrl.dispose();
    transcriptKeyCtrl.dispose(); translateUrlCtrl.dispose(); translateKeyCtrl.dispose();
    yt?.close();
    local?.dispose();
    speech.stop();
    tts.stop();
    super.dispose();
  }

  String? youtubeId(String input) {
    final uri = Uri.tryParse(input.trim());
    if (uri == null) return null;
    if (uri.host == 'youtu.be' || uri.host.endsWith('.youtu.be')) {
      return uri.pathSegments.isNotEmpty ? uri.pathSegments.first : null;
    }
    if (uri.host.contains('youtube.com') || uri.host.contains('youtube-nocookie.com')) {
      if (uri.queryParameters['v']?.isNotEmpty == true) return uri.queryParameters['v'];
      final seg = uri.pathSegments;
      for (final key in ['shorts', 'embed', 'live']) {
        final i = seg.indexOf(key);
        if (i >= 0 && i + 1 < seg.length) return seg[i + 1];
      }
    }
    return null;
  }

  Future<void> openYoutube([String? value]) async {
    final url = (value ?? urlCtrl.text).trim();
    final id = youtubeId(url);
    if (id == null || id.isEmpty) {
      setState(() => status = 'الرابط غير معروف. استخدم رابط YouTube صالحًا.');
      return;
    }
    final oldLocal = local; final oldYt = yt;
    local = null; localReady = false; yt = null;
    if (mounted) setState(() {});
    await oldLocal?.dispose();
    await oldYt?.close();
    yt = YoutubePlayerController.fromVideoId(
      videoId: id,
      autoPlay: false,
      params: const YoutubePlayerParams(showFullscreenButton: true, showControls: true),
    );
    urlCtrl.text = url;
    videoTitle = 'فيديو YouTube';
    status = 'يمكنك الآن تشغيل الفيديو وإضافة ملف ترجمة بصيغة SRT أو VTT أو TXT.';
    await widget.onRecent(url, videoTitle);
    if (mounted) setState(() {});
  }

  Future<void> openLocal() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video);
    if (result == null || result.files.single.path == null) return;
    final oldLocal = local; final oldYt = yt;
    local = null; localReady = false; yt = null;
    if (mounted) setState(() {});
    await oldLocal?.dispose();
    await oldYt?.close();
    final file = File(result.files.single.path!);
    local = VideoPlayerController.file(file);
    try {
      await local!.initialize();
      await local!.setPlaybackSpeed(speed);
      local!.addListener(_onLocalVideoTick);
      if (!mounted) return;
      setState(() {
        localReady = true; videoTitle = result.files.single.name;
        status = 'الفيديو المحلي جاهز. حمّل ملف ترجمة لمزامنة الجمل.';
      });
    } catch (e) {
      if (mounted) setState(() => status = 'تعذّر فتح الملف: $e');
    }
  }

  Future<void> importSubtitles() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any);
    if (result == null || result.files.single.path == null) return;
    final ext = result.files.single.name.toLowerCase().split('.').last;
    if (!['srt', 'vtt', 'txt'].contains(ext)) {
      setState(() => status = 'اختر ملف ترجمة بصيغة SRT أو VTT أو TXT.');
      return;
    }
    final content = await File(result.files.single.path!).readAsString();
    final parsed = parseSubtitles(content);
    setState(() {
      lines = parsed;
      current = -1;
      status = parsed.isEmpty ? 'لم أجد جملًا مفهومة في الملف. تحقق من صيغة الترجمة.' : 'تم تحميل ${parsed.length} جملة.';
    });
  }

  List<SubtitleLine> parseSubtitles(String input) {
    final normalized = input.replaceAll('\r\n', '\n').replaceAll('\r', '\n').replaceAll('\uFEFF', '');
    final blocks = normalized.split(RegExp(r'\n\s*\n'));
    final result = <SubtitleLine>[];
    for (final block in blocks) {
      final rows = block.split('\n').map((x) => x.trim()).where((x) => x.isNotEmpty).toList();
      if (rows.isEmpty || rows.first.toUpperCase() == 'WEBVTT') continue;
      int timeIndex = rows.indexWhere((x) => x.contains('-->'));
      if (timeIndex < 0) {
        if (rows.length == 1 && !rows.first.startsWith('{')) {
          result.add(SubtitleLine(Duration.zero, Duration.zero, rows.first));
        }
        continue;
      }
      final times = rows[timeIndex].split('-->');
      if (times.length < 2) continue;
      final start = parseTime(times[0].trim());
      final end = parseTime(times[1].trim().split(RegExp(r'\s+')).first);
      if (start == null || end == null) continue;
      final text = rows.skip(timeIndex + 1).join(' ').replaceAll(RegExp(r'<[^>]*>'), '').trim();
      if (text.isNotEmpty) result.add(SubtitleLine(start, end, text));
    }
    result.sort((a,b) => a.start.compareTo(b.start));
    return result;
  }

  Duration? parseTime(String s) {
    final parts = s.replaceAll(',', '.').split(':');
    if (parts.length < 2 || parts.length > 3) return null;
    try {
      final secParts = parts.last.split('.');
      final seconds = int.parse(secParts[0]);
      final ms = secParts.length > 1 ? int.parse((secParts[1] + '000').substring(0,3)) : 0;
      final minutes = int.parse(parts[parts.length - 2]);
      final hours = parts.length == 3 ? int.parse(parts[0]) : 0;
      return Duration(hours: hours, minutes: minutes, seconds: seconds, milliseconds: ms);
    } catch (_) { return null; }
  }


  void _onLocalVideoTick() {
    final controller = local;
    if (controller == null || !controller.value.isInitialized || lines.isEmpty || !mounted) return;
    final pos = controller.value.position;
    final playing = controller.value.isPlaying;
    if (playing != _lastPlaying || pos.inSeconds != _lastSecond) {
      _lastPlaying = playing; _lastSecond = pos.inSeconds;
      setState(() {});
    }
    final index = lines.indexWhere((line) => pos >= line.start && pos <= line.end);
    if (followPlayback && index >= 0 && index != current) {
      setState(() => current = index);
    }
    if (repeatSentence && current >= 0 && current < lines.length && controller.value.isPlaying) {
      final line = lines[current];
      if (line.end > line.start && pos >= line.end) {
        controller.seekTo(line.start);
      }
    }
  }

  Future<void> speakLine(SubtitleLine line, {bool translated = false}) async {
    final text = translated && line.translation.trim().isNotEmpty ? line.translation : line.text;
    if (text.trim().isEmpty) return;
    try {
      await tts.stop();
      // Let the platform choose a voice when a language-specific voice is unavailable.
      final language = translated ? (targetLanguage == 'ar' ? 'ar-SA' : targetLanguage) : speechLocale.replaceAll('_', '-');
      await tts.setLanguage(language);
      await tts.setSpeechRate(0.42);
      await tts.speak(text);
    } catch (_) {
      if (mounted) setState(() => autoInfo = 'ميزة النطق غير مدعومة بهذه اللغة على الجهاز.');
    }
  }

  Future<void> speakSavedText(String text) async {
    if (text.trim().isEmpty) return;
    try {
      await tts.stop();
      await tts.setLanguage(speechLocale.replaceAll('_', '-'));
      await tts.setSpeechRate(0.42);
      await tts.speak(text);
    } catch (_) {}
  }

  Future<void> saveWordFromLine(SubtitleLine line) async {
    final wordCtrl = TextEditingController();
    final meaningCtrl = TextEditingController();
    final chosen = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حفظ كلمة للمراجعة'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('من الجملة: ${line.text}', maxLines: 3, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 10),
          TextField(controller: wordCtrl, autofocus: true, decoration: const InputDecoration(labelText: 'الكلمة أو التعبير')),
          const SizedBox(height: 8),
          TextField(controller: meaningCtrl, decoration: const InputDecoration(labelText: 'المعنى بالعربية')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (chosen == true && wordCtrl.text.trim().isNotEmpty) {
      await widget.onSave(Phrase(
        wordCtrl.text.trim(),
        meaningCtrl.text.trim(),
        'مفردة · $videoTitle · ${line.text}',
        DateTime.now(),
      ));
    }
  }

  Future<void> togglePlay() async {
    if (localReady && local != null) {
      if (local!.value.isPlaying) { await local!.pause(); } else { await local!.play(); }
      if (mounted) setState(() {});
    }
  }

  Future<void> setSpeed(double v) async {
    setState(() => speed = v);
    if (localReady && local != null) await local!.setPlaybackSpeed(v);
    // YouTube playback rate selection is intentionally not forced by the iframe API.
  }

  Future<void> seekToLine(SubtitleLine line, int index) async {
    setState(() => current = index);
    if (localReady && local != null) {
      await local!.seekTo(line.start);
      await local!.play();
      if (mounted) setState(() {});
    } else if (yt != null) {
      await yt!.seekTo(seconds: line.start.inMilliseconds / 1000.0, allowSeekAhead: true);
      await yt!.playVideo();
    } else {
      setState(() => status = 'افتح فيديو أولًا. التوقيت متاح للانتقال إلى الجملة بعد فتح الفيديو.');
    }
  }

  Future<void> startListening() async {
    final available = await speech.initialize(
      onStatus: (s) { if ((s == 'notListening' || s == 'done') && mounted) setState(() => listening = false); },
      onError: (_) { if (mounted) setState(() => listening = false); },
    );
    if (!available) {
      if (mounted) setState(() => status = 'التعرّف على الصوت غير متاح. تحقق من إذن الميكروفون واللغة المثبتة.');
      return;
    }
    setState(() { listening = true; recognized = ''; });
    await speech.listen(
      localeId: speechLocale,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
      onResult: (r) { if (mounted) setState(() => recognized = r.recognizedWords); },
    );
  }
  Future<void> stopListening() async { await speech.stop(); if (mounted) setState(() => listening = false); }

  double pronunciationSimilarity(String expected, String actual) {
    String normalize(String value) => value.toLowerCase()
      .replaceAll(RegExp(r'[.,!?;:،؟«»“”()\[\]{}]'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
    final a = normalize(expected).split(' ').where((x) => x.isNotEmpty).toSet();
    final b = normalize(actual).split(' ').where((x) => x.isNotEmpty).toSet();
    if (a.isEmpty || b.isEmpty) return 0;
    return (a.intersection(b).length / a.union(b).length) * 100;
  }


  Future<void> apiSettings() async {
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('إعدادات التفريغ والترجمة'),
      content: StatefulBuilder(builder: (context, setDialogState) => SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('يستخدم التفريغ خدمة خارجية ومفتاح API. افتراضيًا نطلب الترجمات المتاحة فقط لتقليل احتمال استهلاك الرصيد. فعّل التعرف الآلي على الصوت فقط إذا وافقت على احتمال احتساب رصيد.'),
        const SizedBox(height: 12),
        TextField(controller: transcriptKeyCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'مفتاح YouTubeTranscriptAPI')),
        const SizedBox(height: 10),
        TextField(controller: translateUrlCtrl, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'عنوان خدمة الترجمة', hintText: 'https://libretranslate.com')),
        const SizedBox(height: 10),
        TextField(controller: translateKeyCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'مفتاح خدمة الترجمة (إن لزم)')),
        const SizedBox(height: 10),
        StatefulBuilder(builder: (context, setDialogState) => SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('السماح بالتعرف الآلي على الصوت (ASR)'),
          subtitle: const Text('قد يستهلك رصيدًا لدى مزود التفريغ إذا لم تتوفر ترجمة جاهزة.'),
          value: allowPaidAsr,
          onChanged: (v) { setDialogState(() => allowPaidAsr = v); },
        )),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: targetLanguage,
          decoration: const InputDecoration(labelText: 'الترجمة إلى'),
          items: const [
            DropdownMenuItem(value: 'ar', child: Text('العربية')),
            DropdownMenuItem(value: 'fr', child: Text('الفرنسية')),
            DropdownMenuItem(value: 'en', child: Text('الإنجليزية')),
            DropdownMenuItem(value: 'es', child: Text('الإسبانية')),
            DropdownMenuItem(value: 'de', child: Text('الألمانية')),
            DropdownMenuItem(value: 'it', child: Text('الإيطالية')),
          ],
          onChanged: (v) { if (v != null) setDialogState(() => targetLanguage = v); },
        ),
        const SizedBox(height: 8),
        const Text('لا ترسل مفاتيحك لأي شخص. تُحفظ محليًا على الجهاز، لكن SharedPreferences ليست خزنة مشفرة.', style: TextStyle(fontSize: 12)),
      ]))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final p = await SharedPreferences.getInstance();
          await p.setString('transcript_api_key', transcriptKeyCtrl.text.trim());
          await p.setString('translate_base_url', translateUrlCtrl.text.trim().replaceAll(RegExp(r'/+$'), ''));
          await p.setString('translate_api_key', translateKeyCtrl.text.trim());
          await p.setString('target_language', targetLanguage);
          await p.setBool('allow_paid_asr', allowPaidAsr);
          if (ctx.mounted) Navigator.pop(ctx);
          if (mounted) setState(() => autoInfo = 'تم حفظ الإعدادات على الجهاز.');
        }, child: const Text('حفظ')),
      ],
    ));
  }

  Future<void> autoTranscriptAndTranslate() async {
    final id = youtubeId(urlCtrl.text);
    final key = transcriptKeyCtrl.text.trim();
    if (id == null) {
      setState(() => autoInfo = 'أدخل رابط YouTube صالحًا أولًا.');
      return;
    }
    if (key.isEmpty) {
      setState(() => autoInfo = 'أضف مفتاح API من زر الإعدادات أولًا.');
      await apiSettings();
      if (transcriptKeyCtrl.text.trim().isEmpty) return;
    }
    setState(() { autoBusy = true; autoInfo = 'جارٍ طلب التفريغ…'; });
    try {
      final response = await http.post(
        Uri.parse('https://www.youtubetranscript.dev/api/v2/transcribe'),
        headers: {'Authorization': 'Bearer ${transcriptKeyCtrl.text.trim()}', 'Content-Type': 'application/json'},
        body: jsonEncode({
          'video': urlCtrl.text.trim(),
          'mode': allowPaidAsr ? 'auto' : 'captions_only',
          'format': {'timestamp': true, 'paragraphs': true}
        }),
      ).timeout(const Duration(seconds: 45));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        String detail = '';
        try {
          final err = jsonDecode(response.body);
          detail = (err['message'] ?? err['error'] ?? '').toString();
        } catch (_) {}
        throw Exception('خدمة التفريغ ردّت برمز ${response.statusCode}. ${detail.isNotEmpty ? detail : 'تحقق من المفتاح وحدود الاستخدام.'}');
      }
      var data = jsonDecode(response.body) as Map<String, dynamic>;
      if ((data['status'] == 'processing' || data['job_id'] != null) && data['data'] == null) {
        final jobId = data['job_id']?.toString();
        if (jobId == null || jobId.isEmpty) {
          throw Exception('بدأ التفريغ لكن لم تُرجع الخدمة رقم المهمة.');
        }
        var finished = false;
        for (var i = 0; i < 30; i++) {
          await Future.delayed(const Duration(seconds: 3));
          final poll = await http.get(
            Uri.parse('https://www.youtubetranscript.dev/api/v2/jobs/${Uri.encodeComponent(jobId)}'),
            headers: {'Authorization': 'Bearer ${transcriptKeyCtrl.text.trim()}'},
          ).timeout(const Duration(seconds: 25));
          if (poll.statusCode < 200 || poll.statusCode >= 300) continue;
          data = jsonDecode(poll.body) as Map<String, dynamic>;
          if (data['status'] == 'completed' || data['data'] != null) { finished = true; break; }
          if (data['status'] == 'failed') throw Exception('تعذّر تفريغ الصوت. جرّب فيديو آخر.');
          if (mounted) setState(() => autoInfo = 'يجري تحويل الصوت إلى نص… (${i + 1}/30)');
        }
        if (!finished) throw Exception('استغرق التفريغ وقتًا طويلًا. أعد المحاولة لاحقًا.');
      }
      final root = (data['data'] is Map<String, dynamic>) ? data['data'] as Map<String, dynamic> : data;
      final transcript = (root['transcript'] is Map<String, dynamic>) ? root['transcript'] as Map<String, dynamic> : <String, dynamic>{};
      final rawSegments = transcript['segments'] ?? root['segments'];
      if (rawSegments is! List || rawSegments.isEmpty) {
        throw Exception(allowPaidAsr
          ? 'لم تُرجع الخدمة مقاطع نصية. قد يكون الفيديو غير متاح أو لم تكتمل المهمة.'
          : 'لم أجد ترجمة مصاحبة متاحة لهذا الفيديو. افتح الإعدادات وفعّل «السماح بالتعرف الآلي على الصوت» إذا كنت توافق على احتمال استهلاك رصيد، أو استورد ملف SRT/VTT.');
      }
      final parsed = <SubtitleLine>[];
      for (final item in rawSegments) {
        if (item is! Map) continue;
        final text = (item['text'] ?? '').toString().trim();
        if (text.isEmpty) continue;
        final startValue = item['start'];
        final endValue = item['end'];
        final startMs = _toMilliseconds(startValue);
        final endMs = endValue == null ? startMs + 3000 : _toMilliseconds(endValue);
        parsed.add(SubtitleLine(Duration(milliseconds: startMs), Duration(milliseconds: endMs), text));
      }
      if (parsed.isEmpty) throw Exception('لم يتم العثور على جمل قابلة للعرض.');
      setState(() { lines = parsed; current = -1; autoInfo = 'تم استخراج ${parsed.length} مقطعًا. جارٍ الترجمة…'; });
      await _translateLines();
      if (mounted) setState(() => autoInfo = 'اكتمل التفريغ والترجمة. يمكنك الضغط على أي جملة للانتقال إلى توقيتها.');
    } catch (e) {
      if (mounted) setState(() => autoInfo = 'لم تكتمل العملية: ${e.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => autoBusy = false);
    }
  }

  int _toMilliseconds(dynamic value) {
    // Transcript APIs vary: numeric timestamps are usually seconds, while large
    // values are often already milliseconds. Accept both forms defensively.
    if (value is int) return value >= 100000 ? value : value * 1000;
    if (value is num) return value >= 100000 ? value.round() : (value * 1000).round();
    if (value is String) {
      final n = num.tryParse(value.trim());
      if (n != null) return n >= 100000 ? n.round() : (n * 1000).round();
      final d = parseTime(value);
      if (d != null) return d.inMilliseconds;
    }
    return 0;
  }


  Future<void> exportSubtitles() async {
    if (lines.isEmpty) {
      setState(() => autoInfo = 'لا توجد جمل لتصديرها بعد.');
      return;
    }
    String stamp(Duration d) {
      final h = d.inHours.toString().padLeft(2, '0');
      final m = (d.inMinutes % 60).toString().padLeft(2, '0');
      final sec = (d.inSeconds % 60).toString().padLeft(2, '0');
      final ms = (d.inMilliseconds % 1000).toString().padLeft(3, '0');
      return '$h:$m:$sec,$ms';
    }
    final out = StringBuffer();
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      out.writeln(i + 1);
      out.writeln('${stamp(line.start)} --> ${stamp(line.end > line.start ? line.end : line.start + const Duration(seconds: 3))}');
      out.writeln(line.text);
      if (line.translation.trim().isNotEmpty) out.writeln(line.translation.trim());
      out.writeln();
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/lisaan_subtitles.srt');
    await file.writeAsString(out.toString(), encoding: utf8);
    await Share.shareXFiles([XFile(file.path)], text: 'ملف ترجمة صادر من لسان');
  }

  Future<void> _translateLines() async {
    final base = translateUrlCtrl.text.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty) throw Exception('أدخل عنوان خدمة الترجمة من الإعدادات.');
    final p = await SharedPreferences.getInstance();
    final apiKey = p.getString('translate_api_key') ?? '';
    final target = p.getString('target_language') ?? 'ar';
    final updated = <SubtitleLine>[];
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      try {
        final body = <String, dynamic>{'q': line.text, 'source': 'auto', 'target': target, 'format': 'text'};
        if (apiKey.isNotEmpty) body['api_key'] = apiKey;
        final res = await http.post(
          Uri.parse('$base/translate'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(body),
        ).timeout(const Duration(seconds: 20));
        if (res.statusCode >= 200 && res.statusCode < 300) {
          final j = jsonDecode(res.body);
          updated.add(SubtitleLine(line.start, line.end, line.text, (j['translatedText'] ?? '').toString()));
        } else {
          updated.add(line);
        }
      } catch (_) { updated.add(line); }
      if (mounted && i % 5 == 0) setState(() => autoInfo = 'جارٍ ترجمة الجمل… ${i + 1}/${lines.length}');
    }
    if (mounted) setState(() => lines = updated);
  }

  @override
  Widget build(BuildContext context) {
    final active = current >= 0 && current < lines.length ? lines[current] : null;
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(22)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('تعلّم من المحتوى الذي تحبّه', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
          SizedBox(height: 7),
          Text('شاهد، اقرأ الجمل، كرّر النطق، واحفظ المفردات المهمة.', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 16),
      TextField(controller: urlCtrl, keyboardType: TextInputType.url, decoration: const InputDecoration(prefixIcon: Icon(Icons.link), hintText: 'الصق رابط YouTube هنا')),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: FilledButton.icon(onPressed: () => openYoutube(), icon: const Icon(Icons.play_arrow), label: const Text('فتح YouTube'))),
        const SizedBox(width: 8),
        OutlinedButton.icon(onPressed: openLocal, icon: const Icon(Icons.video_file), label: const Text('فيديو محلي')),
      ]),
      if (widget.recent.isNotEmpty) ...[
        const SizedBox(height: 8),
        SizedBox(height: 38, child: ListView(scrollDirection: Axis.horizontal, children: widget.recent.map((r) => Padding(
          padding: const EdgeInsetsDirectional.only(end: 6),
          child: ActionChip(avatar: const Icon(Icons.history, size: 16), label: Text(r['title'] ?? 'سابق'), onPressed: () => openYoutube(r['url'])),
        )).toList())),
      ],
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: FilledButton.icon(
          onPressed: autoBusy ? null : autoTranscriptAndTranslate,
          icon: autoBusy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
          label: Text(autoBusy ? 'جارٍ المعالجة…' : 'تفريغ وترجمة تلقائيًا'),
        )),
        IconButton(tooltip: 'إعدادات API', onPressed: apiSettings, icon: const Icon(Icons.settings)),
      ]),
      if (autoInfo.isNotEmpty) Card(color: const Color(0xFFE1F1EB), child: Padding(padding: const EdgeInsets.all(12), child: Text(autoInfo))),
      const SizedBox(height: 12),
      if (yt != null) ClipRRect(borderRadius: BorderRadius.circular(16), child: YoutubePlayer(controller: yt!, aspectRatio: 16/9)),
      if (localReady && local != null) ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: AspectRatio(aspectRatio: local!.value.aspectRatio, child: VideoPlayer(local!)),
      ),
      if (localReady && local != null) Row(children: [
        IconButton(onPressed: togglePlay, icon: Icon(local!.value.isPlaying ? Icons.pause_circle : Icons.play_circle, size: 34)),
        Expanded(child: VideoProgressIndicator(local!, allowScrubbing: true, padding: const EdgeInsets.symmetric(vertical: 12))),
        const SizedBox(width: 8),
        Text('${local!.value.position.inMinutes}:${(local!.value.position.inSeconds % 60).toString().padLeft(2,'0')}'),
      ]),
      const SizedBox(height: 10),
      Card(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        const Icon(Icons.info_outline, color: brand), const SizedBox(width: 8),
        Expanded(child: Text(status, style: const TextStyle(fontSize: 13))),
      ]))),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: importSubtitles, icon: const Icon(Icons.subtitles), label: const Text('استيراد ترجمة'))),
        const SizedBox(width: 8),
        PopupMenuButton<double>(
          initialValue: speed,
          onSelected: setSpeed,
          itemBuilder: (_) => const [
            PopupMenuItem(value: 0.5, child: Text('0.5×')),
            PopupMenuItem(value: 0.75, child: Text('0.75×')),
            PopupMenuItem(value: 1, child: Text('1×')),
            PopupMenuItem(value: 1.25, child: Text('1.25×')),
            PopupMenuItem(value: 1.5, child: Text('1.5×')),
          ],
          child: Chip(avatar: const Icon(Icons.speed), label: Text('${speed}×')),
        ),
      ]),
      if (lines.isNotEmpty) ...[
        const SizedBox(height: 8),
        TextField(controller: searchCtrl, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث داخل الجمل'), onChanged: (_) => setState(() {})),
        if (active != null) Card(color: const Color(0xFFE1F1EB), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('الجملة المحددة', style: TextStyle(color: brand, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6), SelectableText(active.text, style: const TextStyle(fontSize: 18)),
          if (active.translation.isNotEmpty) Text(active.translation),
          Wrap(alignment: WrapAlignment.end, spacing: 4, children: [
            IconButton(tooltip: 'استمع إلى الجملة', onPressed: () => speakLine(active), icon: const Icon(Icons.volume_up)),
            if (active.translation.isNotEmpty) IconButton(tooltip: 'استمع إلى الترجمة', onPressed: () => speakLine(active, translated: true), icon: const Icon(Icons.translate)),
            IconButton(tooltip: 'حفظ العبارة', onPressed: () => widget.onSave(Phrase(active.text, active.translation, videoTitle, DateTime.now())), icon: const Icon(Icons.bookmark_add)),
            IconButton(tooltip: 'حفظ كلمة للمراجعة', onPressed: () => saveWordFromLine(active), icon: const Icon(Icons.spellcheck)),
          ]),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), child: Column(children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تحديد الجملة تلقائيًا مع الفيديو'),
            value: followPlayback,
            onChanged: (v) => setState(() => followPlayback = v),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تكرار الجملة المحددة'),
            subtitle: const Text('يعمل مع الفيديو المحلي عند وجود توقيت للجملة.'),
            value: repeatSentence,
            onChanged: (v) => setState(() => repeatSentence = v),
          ),
        ]))),
        Row(children: [
          const Text('الجمل', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          const Spacer(), Text('${lines.length} جملة'),
          IconButton(tooltip: 'إعادة محاولة الترجمة', onPressed: autoBusy ? null : () async {
            setState(() { autoBusy = true; autoInfo = 'جارٍ إعادة ترجمة الجمل…'; });
            try {
              await _translateLines();
              if (mounted) setState(() => autoInfo = 'انتهت محاولة الترجمة. راجع الجمل التي بقيت دون معنى.');
            } catch (e) {
              if (mounted) setState(() => autoInfo = 'تعذرت إعادة الترجمة: $e');
            } finally {
              if (mounted) setState(() => autoBusy = false);
            }
          }, icon: const Icon(Icons.translate)),
          IconButton(tooltip: 'تصدير SRT', onPressed: exportSubtitles, icon: const Icon(Icons.file_download_outlined)),
        ]),
        ...lines.asMap().entries.where((e) => e.value.text.toLowerCase().contains(searchCtrl.text.toLowerCase())).map((entry) {
          final i = entry.key; final line = entry.value;
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            color: current == i ? const Color(0xFFE1F1EB) : Colors.white,
            child: ListTile(
              leading: Text(_time(line.start), style: const TextStyle(fontSize: 11)),
              title: Text(line.text),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (line.translation.isNotEmpty) Text(line.translation),
                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(tooltip: 'استماع', visualDensity: VisualDensity.compact, icon: const Icon(Icons.volume_up_outlined), onPressed: () => speakLine(line)),
                    IconButton(tooltip: 'حفظ العبارة', visualDensity: VisualDensity.compact, icon: const Icon(Icons.bookmark_add_outlined), onPressed: () => widget.onSave(Phrase(line.text, line.translation, videoTitle, DateTime.now()))),
                    IconButton(tooltip: 'حفظ كلمة', visualDensity: VisualDensity.compact, icon: const Icon(Icons.spellcheck), onPressed: () => saveWordFromLine(line)),
                  ]),
                ),
              ]),
              onTap: () => seekToLine(line, i),
            ),
          );
        }),
      ],
      const SizedBox(height: 18),
      const Divider(),
      Text('تدريب النطق', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: speechLocale,
        decoration: const InputDecoration(labelText: 'لغة التعرّف على الكلام'),
        items: const [
          DropdownMenuItem(value: 'en_US', child: Text('الإنجليزية')),
          DropdownMenuItem(value: 'fr_FR', child: Text('الفرنسية')),
          DropdownMenuItem(value: 'ar_DZ', child: Text('العربية الجزائرية (إن توفرت)')),
          DropdownMenuItem(value: 'es_ES', child: Text('الإسبانية')),
        ],
        onChanged: (v) { if (v != null) setState(() => speechLocale = v); },
      ),
      const SizedBox(height: 8),
      FilledButton.tonalIcon(onPressed: listening ? stopListening : startListening, icon: Icon(listening ? Icons.stop : Icons.mic), label: Text(listening ? 'إيقاف الاستماع' : 'تحدث بالميكروفون')),
      if (recognized.isNotEmpty) Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('النص الذي تعرّف عليه الهاتف', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          SelectableText(recognized),
          if ((active?.text ?? sourceCtrl.text).trim().isNotEmpty) ...[
            const SizedBox(height: 8),
            Builder(builder: (_) {
              final score = pronunciationSimilarity(active?.text ?? sourceCtrl.text, recognized);
              return Row(children: [
                const Icon(Icons.insights, size: 18),
                const SizedBox(width: 6),
                Expanded(child: Text('تشابه الكلمات التقريبي: ${score.round()}%')),
              ]);
            }),
            const SizedBox(height: 4),
            const Text('هذا مؤشر نصّي تقريبي وليس تقييمًا صوتيًا دقيقًا للنطق أو اللكنة.', style: TextStyle(fontSize: 11)),
          ],
        ],
      ))),
      if (recognized.isNotEmpty) Align(alignment: AlignmentDirectional.centerEnd, child: TextButton.icon(onPressed: () {
        sourceCtrl.text = recognized;
        setState(() {});
      }, icon: const Icon(Icons.copy), label: const Text('استخدم النص كعبارة'))),
      if (sourceCtrl.text.isNotEmpty || translationCtrl.text.isNotEmpty) const SizedBox(height: 6),
      TextField(controller: sourceCtrl, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'العبارة الأصلية')),
      const SizedBox(height: 8),
      TextField(controller: translationCtrl, minLines: 1, maxLines: 3, decoration: const InputDecoration(labelText: 'المعنى بلغتك')),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: () {
        if (sourceCtrl.text.trim().isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('اكتب عبارة أولًا')));
          return;
        }
        widget.onSave(Phrase(sourceCtrl.text.trim(), translationCtrl.text.trim(), videoTitle, DateTime.now()));
        sourceCtrl.clear(); translationCtrl.clear(); setState(() {});
      }, icon: const Icon(Icons.bookmark_add), label: const Text('حفظ العبارة')),
      const SizedBox(height: 18),
    ]);
  }
  String _time(Duration d) => '${d.inMinutes.toString().padLeft(2,'0')}:${(d.inSeconds % 60).toString().padLeft(2,'0')}';
}

class SavedPage extends StatefulWidget {
  final List<Phrase> phrases;
  final Future<void> Function(int) onDelete;
  const SavedPage({super.key, required this.phrases, required this.onDelete});
  @override
  State<SavedPage> createState() => _SavedPageState();
}
class _SavedPageState extends State<SavedPage> {
  String query = '';
  bool reviewMode = false;
  bool revealMeaning = false;
  int reviewIndex = 0;
  bool wordsOnly = false;
  @override
  Widget build(BuildContext context) {
    final items = widget.phrases.where((p) {
      final isWord = p.context.startsWith('مفردة ·');
      return (!wordsOnly || isWord) &&
        '${p.source} ${p.translation} ${p.context}'.toLowerCase().contains(query.toLowerCase());
    }).toList();
    if (reviewIndex >= items.length) reviewIndex = 0;
    return Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Row(children: [
        Expanded(child: Text(wordsOnly ? 'كلماتي' : 'عباراتي', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold))),
        IconButton(tooltip: 'مراجعة البطاقات', onPressed: items.isEmpty ? null : () => setState(() { reviewMode = !reviewMode; revealMeaning = false; }), icon: Icon(reviewMode ? Icons.list_alt : Icons.style)),
        IconButton(tooltip: 'عرض الكلمات فقط', onPressed: () => setState(() { wordsOnly = !wordsOnly; reviewMode = false; }), icon: Icon(wordsOnly ? Icons.spellcheck : Icons.menu_book)),
        IconButton(tooltip: 'تصدير نسخة احتياطية', onPressed: widget.phrases.isEmpty ? null : () async {
          final data = const JsonEncoder.withIndent('  ').convert(widget.phrases.map((p) => p.toJson()).toList());
          final dir = await getTemporaryDirectory();
          final file = File('${dir.path}/lisaan_phrases.json');
          await file.writeAsString(data);
          await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية من عبارات لسان');
        }, icon: const Icon(Icons.ios_share)),
      ]),
      TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'ابحث في العبارات المحفوظة'), onChanged: (v) => setState(() => query = v)),
      const SizedBox(height: 12),
      Expanded(child: items.isEmpty ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.bookmark_border, size: 56, color: Colors.grey),
        const SizedBox(height: 8),
        Text(widget.phrases.isEmpty ? 'لم تحفظ أي عبارة بعد' : 'لا توجد نتائج'),
        const Text('احفظ الجمل أو الكلمات من صفحة التعلّم لتراجعها هنا.', textAlign: TextAlign.center),
      ])) : reviewMode ? Column(children: [
        Text('بطاقة ${reviewIndex + 1} من ${items.length}', style: TextStyle(color: Colors.grey.shade700)),
        const SizedBox(height: 10),
        Expanded(child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => setState(() => revealMeaning = !revealMeaning),
          child: Card(
            color: const Color(0xFFE1F1EB),
            child: Center(child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(revealMeaning ? Icons.translate : Icons.touch_app, size: 36, color: brand),
                const SizedBox(height: 16),
                Text(revealMeaning ? (items[reviewIndex].translation.isEmpty ? 'لم تضف معنى لهذه البطاقة' : items[reviewIndex].translation) : items[reviewIndex].source,
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w700)),
                const SizedBox(height: 14),
                Text(revealMeaning ? items[reviewIndex].source : 'اضغط لإظهار المعنى', style: const TextStyle(fontSize: 13)),
              ]),
            )),
          ),
        )),
        Row(children: [
          OutlinedButton.icon(onPressed: () => setState(() { reviewIndex = (reviewIndex - 1 + items.length) % items.length; revealMeaning = false; }), icon: const Icon(Icons.arrow_back), label: const Text('السابقة')),
          const Spacer(),
          FilledButton.icon(onPressed: () => setState(() { reviewIndex = (reviewIndex + 1) % items.length; revealMeaning = false; }), icon: const Icon(Icons.arrow_forward), label: const Text('التالية')),
        ]),
      ]) : ListView.builder(itemCount: items.length, itemBuilder: (_, i) {
        final p = items[i];
        final originalIndex = widget.phrases.indexOf(p);
        return Card(child: ListTile(
          leading: Icon(p.context.startsWith('مفردة ·') ? Icons.spellcheck : Icons.bookmark_outline, color: brand),
          title: SelectableText(p.source),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (p.translation.isNotEmpty) Text(p.translation),
            if (p.context.isNotEmpty) Text(p.context, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
          ]),
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => widget.onDelete(originalIndex)),
        ));
      })),
    ]));
  }
}

class GuidePage extends StatelessWidget {
  const GuidePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Text('كيف تستخدم لسان؟', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    const _GuideCard(icon: Icons.video_library, title: '1. افتح المحتوى', body: 'الصق رابط YouTube أو اختر فيديو من جهازك. قد لا تسمح بعض الفيديوهات المضمّنة بالتشغيل حسب إعدادات صاحب المحتوى أو قيود المنصة.'),
    const _GuideCard(icon: Icons.subtitles, title: '2. أضف الترجمة', body: 'استورد ملف SRT أو VTT. تظهر الجمل مع توقيتها ويمكنك الضغط على جملة للانتقال إلى وقتها في الفيديو. ملف TXT يُقرأ كنص بسيط وليس مزامنًا إذا لم يتضمن توقيتًا.'),
    const _GuideCard(icon: Icons.bookmark_add, title: '3. احفظ العبارات', body: 'احفظ الجمل أو الكلمات ومعانيها، ثم افتح «عباراتي» واستخدم وضع البطاقات لإخفاء المعنى ومحاولة تذكّره. يمكنك عرض الكلمات فقط وتصدير نسخة احتياطية.'),
    const _GuideCard(icon: Icons.mic, title: '4. تدرّب على الكلام', body: 'اضغط الميكروفون وقل جملة باللغة المختارة. دقة التعرف وتوفر اللغة يعتمدان على الجهاز ومحرك الكلام المثبّت. هذه الميزة لا تقيس تطابق النطق بدقة.'),
    const _GuideCard(icon: Icons.cloud_off, title: 'مهم بشأن المجانية والخصوصية', body: 'التطبيق لا يفرض اشتراكًا داخل نفسه. قد يستخدم التعرف على الكلام خدمة الجهاز أو الإنترنت حسب إعداداته. يمكن تشغيل التفريغ والترجمة التلقائيين من زر «تفريغ وترجمة تلقائيًا» بعد إدخال مفتاح خدمة التفريغ وإعداد خدمة الترجمة. تظل استجابة الخدمات الخارجية وتكاليفها وتوافق واجهاتها خارج ضمان التطبيق. قد تتطلب بعض العمليات رصيدًا أو اتصالًا بالإنترنت، ولا تتوفر لكل فيديو.'),
    const SizedBox(height: 12),
    const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('لسان v1.0.1 — نسخة تجريبية مفتوحة المصدر للتطوير. يلزم بناء التطبيق وتشغيله على جهاز Android لاختبار التوافق النهائي.', textAlign: TextAlign.center))),
  ]);
}
class _GuideCard extends StatelessWidget {
  final IconData icon;
  final String title, body;
  const _GuideCard({required this.icon, required this.title, required this.body});
  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(backgroundColor: const Color(0xFFE1F1EB), child: Icon(icon, color: brand)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 5), Text(body),
      ])),
    ])),
  );
}
